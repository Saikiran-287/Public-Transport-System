package com.src.tests;

public class AdminFunctionsTest {
	public static void main(String args[]) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
			driver.get("Enter Your Driver");
			WebElement adminLoginButton = driver.findElement(By.id("adminLogin"));
			adminLoginButton.click();
			
			WebElement usernameField  = driver.findElement(By.id("uname"));
			WebElement passwordField = driver.findElement(By.id("pwd"));
			WebElement loginButton = driver.findElement(By.id("adminsubmit"));
			usernameField.sendKeys("Your UserName");
			passwordField.sendKeys("Your Password");
			loginButton.click();
			WebElement routesDisplayTab = driver.findElement(By.id("routestab"));
			routesDisplayTab.click();
			WebElement addRoutesButton = driver.findElement(By.id("addRoutes"));
			addRoutesButton.click();
			WebElement routeidField,sourceField, stopsField, destinationField, busnumberField;
			routeidField = driver.findElement(By.id("routeid"));
			sourceField = driver.findElement(By.id("routesource"));
			stopsField = driver.findElement(By.id("routestops"));
			destinationField = driver.findElement(By.id("routedestination"));
			busnumberField = driver.findElement(By.id("rbusnumber"));
			routeidField.sendKeys("ptnmdcl01");
			sourceField.sendKeys("patancheruvu");
			stopsField.sendKeys("bowenpally,suchitra,zeedimetla,kompally,kandlakoya,cmr,checkpost");
			destinationField.sendKeys("medchal");
			busnumberField.sendKeys("219");
			WebElement submitbutton = driver.findElement(By.id("addroutesbutton"));
			submitbutton.click();
			
			WebElement backButton = driver.findElement(By.id ("backbuttonadmin"));
			backButton.click();

			
	}
}
