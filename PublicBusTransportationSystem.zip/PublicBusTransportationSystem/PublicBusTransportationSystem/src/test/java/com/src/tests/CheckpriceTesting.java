package com.src.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;

import org.junit.jupiter.api.Test;

import com.src.service.RoutesService;
import com.src.service.RoutesServiceInterface;

public class CheckpriceTesting {
RoutesServiceInterface rsi = new RoutesService();
Scanner sc = new Scanner(System.in);
	@Test
	public void testCheckPrice() {
		System.out.println("Enter route Id");
		String routeId = sc.next();
		System.out.println("Enter expected value");
		double expected = sc.nextDouble();
		double actual = rsi.checkPrice(routeId);
		assertEquals(expected, actual);
	}

}
