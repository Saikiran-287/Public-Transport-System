// validation.js

function validateForm() {
	var userId = document.forms["registrationForm"]["userid"].value;
	var userName = document.forms["registrationForm"]["uname"].value;
	var password = document.forms["registrationForm"]["upwd"].value;
	var age = document.forms["registrationForm"]["uage"].value;
	var mobileNumber = document.forms["registrationForm"]["umobile"].value;
	var email = document.forms["registrationForm"]["uemail"].value;

	// Regular expressions for validation
	var lettersOnly = /^[A-Za-z]+$/;s
	var passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,32}$/;
	var agePattern = /^\d+$/;
	var mobilePattern = /^\d{10}$/;
	var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

	// Validation checks

	if (userId === "") {
		alert("User ID must not be empty.");
		return false;
	}
	if (userName === "") {
		alert("User Name must not be empty.");
		return false;
	}
	if (password === "") {
		alert("Password must not be empty.");
		return false;
	}
	if (age === "") {
		alert("Age must not be empty.");
		return false;
	}
	if (mobileNumber === "") {
		alert("Mobile Number must not be empty.");
		return false;
	}
	if (email === "") {
		alert("Email id must not be empty.");
		return false;
	}
	if (userId.length > 32) {
		alert("User Id length should be less than 32 characters.");
		return false;
	}

	if (!userName.match(lettersOnly)) {
		alert("Username must have only letters.");
		return false;
	}
	
	if (!password.match(passwordPattern)) {
		alert("Password must have length between 8 and 32, one upper case, one lower case, one special character, and one number.");
		return false;
	}

	if (!age.match(agePattern)) {
		alert("Age must be a number.");
		return false;
	}

	if (!mobileNumber.match(mobilePattern)) {
		alert("Mobile number should be a 10-digit telephone number.");
		return false;
	}

	if (!email.match(emailPattern)) {
		alert("Email should be in a valid format.");
		return false;
	}

	// All fields are valid
	return true;
}
