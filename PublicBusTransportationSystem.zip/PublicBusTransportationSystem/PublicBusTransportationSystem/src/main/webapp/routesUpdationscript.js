
  function validateForm() {
    var uSource = document.forms["routesupform"]["uSource"].value;
    var uMidStops = document.forms["routesupform"]["uMidStops"].value;
    var uDestination = document.forms["routesupform"]["uDestination"].value;
    var uBusNumber = document.forms["routesupform"]["uBusNumber"].value;

    // Regular expression patterns for validation
    var alphanumericPattern = /^[a-zA-Z0-9\s]+$/;
    var alphabetsAndCommaPattern = /^[a-zA-Z,]+$/;
	if (uSource === "") {
      alert("Please enter a Source Name.");
      return false;
    }
    
    if (uMidStops === "") {
      alert("Please enter Stops Name.");
      return false;
    }
    
    if (uDestination === "") {
      alert("Please enter a Destination Name.");
      return false;
    }
    
    if (uBusNumber === "") {
      alert("Please enter a Bus Number.");
      return false;
    }
    if (!uSource.match(alphabetsAndCommaPattern)) {
      alert("Source Name must contain only alphabets.");
      return false;
    }
    
    if (!uMidStops.match(alphabetsAndCommaPattern)) {
      alert("Stops Name must contain only alphabets and commas.");
      return false;
    }
    
    if (!uDestination.match(alphabetsAndCommaPattern)) {
      alert("Destination Name must contain only alphabets.");
      return false;
    }
    
    if (!uBusNumber.match(alphanumericPattern)) {
      alert("Bus Number must be alphanumeric.");
      return false;
    }

    return true;
  }

