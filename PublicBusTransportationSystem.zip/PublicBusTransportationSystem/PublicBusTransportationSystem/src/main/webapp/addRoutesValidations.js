function validateForm() {
  var routeId = document.forms["addRoutesForm"]["routeId"].value;
  var source = document.forms["addRoutesForm"]["source"].value;
  var midStops = document.forms["addRoutesForm"]["midStops"].value;
  var destination = document.forms["addRoutesForm"]["destination"].value;
  var busNumber = document.forms["addRoutesForm"]["busNumber"].value;

  // Check if Route Id is a positive integer
  if (!/^[a-zA-Z0-9]+$/.test(routeId) || routeId === "") {
    alert("Route Id must a non empty string containing only alphanumeric characters.");
    return false;
  }

  // Check if Source, Mid Stops, and Destination are non-empty strings
  if (source === "" || midStops === "" || destination === "") {
    alert("Source, Mid Stops, and Destination must not be empty");
    return false;
  }

  // Check if Bus Number is a non-empty string and contains only alphanumeric characters
  if (!/^[a-zA-Z0-9]+$/.test(busNumber) || busNumber === "") {
    alert("Bus Number must be a non-empty string containing only alphanumeric characters");
    return false;
  }

  // Additional custom validations can be added here if needed

  return true;
}
