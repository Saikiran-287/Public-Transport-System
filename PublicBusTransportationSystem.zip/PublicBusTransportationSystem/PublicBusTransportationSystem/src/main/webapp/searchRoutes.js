function validateForm() {
  var source = document.forms["searchRoutesForm"]["source"].value;
  var destination = document.forms["searchRoutesForm"]["destination"].value;
	 if (source === "") {
    alert("Please enter a source.");
    return false;
  }

  if (destination === "") {
    alert("Please enter a destination.");
    return false;
  }
  // Regular expression to match only alphabetic characters
  var alphabeticRegex = /^[A-Za-z]+$/;

  if (!alphabeticRegex.test(source)) {
    alert("Source should contain only alphabetic characters.");
    return false;
  }

  if (!alphabeticRegex.test(destination)) {
    alert("Destination should contain only alphabetic characters.");
    return false;
  }

  return true;
}
document.addEventListener("DOMContentLoaded", function () {
    const profileLink = document.querySelector(".profile-link");
    const dropdownMenu = profileLink.querySelector(".dropdown-menu");

    // Toggle the dropdown menu on click
    profileLink.addEventListener("click", function (e) {
        e.stopPropagation(); // Prevent the document click event from immediately closing the dropdown
        dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
    });

    // Close the dropdown when clicking anywhere else in the document
    document.addEventListener("click", function () {
        dropdownMenu.style.display = "none";
    });

    // Prevent the dropdown from closing when clicking inside it
    dropdownMenu.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});