document.addEventListener("DOMContentLoaded", function () {
    const profileLink = document.querySelector(".profile-link");
    const dropdownMenu = profileLink.querySelector(".dropdown-menu");

    // Toggle the dropdown menu on click
    profileLink.addEventListener("click", function (e) {
        e.stopPropagation(); // Prevent the document click event from immediately closing the dropdown
        dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
    });

    // Close the dropdown when clicking anywhere else in the document
    document.addEventListener("click", function () {
        dropdownMenu.style.display = "none";
    });

    // Prevent the dropdown from closing when clicking inside it
    dropdownMenu.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});