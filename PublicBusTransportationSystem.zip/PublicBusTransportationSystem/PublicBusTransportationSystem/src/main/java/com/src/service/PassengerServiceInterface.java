package com.src.service;

import java.util.List;

import com.src.model.Passenger;

public interface PassengerServiceInterface {
	public int addPassenger(Passenger p);

	public int deletePassenger(Passenger p);

	public int updatePassenger(Passenger p);
	
	public Passenger getPassenger(String id);
	
	public List<Passenger> getAllPassengers();
}
