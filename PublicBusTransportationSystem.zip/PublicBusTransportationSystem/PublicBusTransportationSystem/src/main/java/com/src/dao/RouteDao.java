package com.src.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.src.model.Routes;

public class RouteDao implements RoutesDaoService {
	DaoService ds = new DaoService();

	@Override
	public int addRoutes(Routes r) {
		int i = 0;
		Statement st = ds.getMyStatement();
		String addQuery = "insert into routes values('" + r.getRouteId() + "','" + r.getRouteSource() + "'," + "'"
				+ r.getRouteDestination() + "','" + r.getMidStops() + "','" + r.getBusNumber() + "')";
		try {
			i = st.executeUpdate(addQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ds.closeMyStatement();
		return i;
	}

	@Override
	public int deleteRoutes(Routes r) {
		// TODO Auto-generated method stub
		int i = 0;
		Statement st = ds.getMyStatement();

		try {
			String deleteQuery = "delete from routes where routeId= '" + r.getRouteId() + "'";
			i = st.executeUpdate(deleteQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ds.closeMyStatement();
		return i;
	}

	@Override
	public int updateRoutes(Routes r) {
		int i = 0;
		Statement st = ds.getMyStatement();

		try {
			String updateQuery = "update routes set routeSource = '" + r.getRouteSource() + "',routeDestination='"
					+ r.getRouteDestination() + "',midStops='" + r.getMidStops() + "',busNumber='" + r.getBusNumber()
					+ "' where routeId = '"+r.getRouteId()+"'";
			i = st.executeUpdate(updateQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ds.closeMyStatement();
		return i;
	}

	@Override
	public List<Routes> getRoutesBySrcDest(String source, String dest) {
		source = source.toLowerCase();
		dest = dest.toLowerCase();
		// TODO Auto-generated method stub
		List<Routes> routevalues = getAllRoutes();
		List<Routes> matchedRoutes = new ArrayList<Routes>();
		for (Routes r : routevalues) {
			if (r.getRouteSource().equalsIgnoreCase(source)||r.getMidStops().contains(source)) {
				if (r.getRouteDestination().equalsIgnoreCase(dest) || r.getMidStops().contains(dest)) {
						matchedRoutes.add(r);
				}
			}
			else if(r.getRouteDestination().equalsIgnoreCase(source) || r.getMidStops().contains(source)) {
				if(r.getRouteSource().equalsIgnoreCase(dest) || r.getMidStops().contains(dest)) {
					matchedRoutes.add(r);
				}
			}
		}
		return matchedRoutes;
	}

	@Override
	public List<Routes> getAllRoutes() {
		// TODO Auto-generated method stub
		Statement st = ds.getMyStatement();
		List<Routes> routes = new ArrayList<Routes>();
		ResultSet rs = null;

		try {
			String displayQuery = "select * from routes";
			rs = st.executeQuery(displayQuery);
			while (rs.next()) {
				Routes r = new Routes(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5));
				routes.add(r);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return routes;
	}
	
	public Routes getRoutes(String routeId) {
		Statement st = ds.getMyStatement();
		Routes r = null;
		ResultSet rs = null;
		
		String query  = "select * from routes where routeId='"+routeId+"'";
		try {
			rs = st.executeQuery(query);
			if(rs.next()) {
				r = new Routes(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}

	@Override
	public double checkPrice(String routeId) {
		// TODO Auto-generated method stub

		Routes r = getRoutes(routeId);
		
		//System.out.println(r);
		String stops = r.getMidStops();
		//System.out.println(stops);
		String[] stop = stops.split(",");
		int numberOfStops = stop.length;
		return numberOfStops * 3.5;

	}

}
