package com.src.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.src.model.Passenger;


public class PassengerDao implements PassengerDaoService {
	DaoService dao = new DaoService();

	@Override
	public int addPassenger(Passenger p) {
		int i = 0;
		Statement st = dao.getMyStatement();
		System.out.println(p.getPassengerId());
		String query = "insert into appusers values('" + p.getPassengerId() + "','" + p.getPassengerName() + "','"
				+ p.getPassword() + "'," + p.getPassengerAge() + "," + p.getPassengerMobileNumber() + ",'"
				+ p.getPassengerEmailId() + "')";
		try {
			i = st.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		dao.closeMyStatement();
		// TODO Auto-generated method stub
		return i;
	}

	@Override
	public int deletePassenger(Passenger p) {
		int i = 0;
		Statement st = dao.getMyStatement();
		String query = "delete from appusers where passengerId='" + p.getPassengerId() + "'";
		try {
			i = st.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dao.closeMyStatement();
		return i;
	}

	@Override
	public int updatePassenger(Passenger p) {
		// TODO Auto-generated method stub
		int i = 0;
		Statement st = dao.getMyStatement();
		String query = "update appusers set passengerName = '" + p.getPassengerName() + "', passengerAge ="
				+ p.getPassengerAge() + ", pwd = '"+p.getPassword()+"',mobile = " + p.getPassengerMobileNumber() + ",emailid= '"
				+ p.getPassengerEmailId() + "' where passengerId = '"+p.getPassengerId()+"'";
		try {
			i = st.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dao.closeMyStatement();
		return i;
	}

	@Override
	public Passenger getPassenger(String id) {
		// TODO Auto-generated method stub
		ResultSet rs = null;
		Statement st = dao.getMyStatement();
		String query = "select * from appusers where passengerId = '" + id + "'";
		Passenger p = null;
		try {
			rs = st.executeQuery(query);
			if (rs.next()) {
				p = new Passenger(rs.getString(1), rs.getString(2), rs.getInt(4), rs.getString(3), rs.getLong(5),
						rs.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dao.closeMyStatement();
		return p;
	}

	@Override
	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		List<Passenger> passengers = new ArrayList<Passenger>();
		ResultSet rs = null;
		Passenger p = null;
		Statement st = dao.getMyStatement();
		String query = "select * from appusers";
		try {
			rs = st.executeQuery(query);
			while (rs.next()) {
				p = new Passenger(rs.getString(1), rs.getString(2), rs.getInt(4), rs.getString(3), rs.getLong(5),
						rs.getString(6));
				passengers.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dao.closeMyStatement();
		return passengers;
	}

	

}
