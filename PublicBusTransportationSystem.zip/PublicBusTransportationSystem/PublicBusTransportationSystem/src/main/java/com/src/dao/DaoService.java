package com.src.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class DaoService {
	private Connection con=null;
	private Statement st=null;
	
	public Statement getMyStatement()
	{
		try {
			Class.forName("Your Driver Herre"); 
			con = DriverManager.getConnection("DataBase Connection URL here");
			st=con.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return st;		
	}
	
	public void closeMyStatement()
	{
		try {
			st.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
