package com.src.model;

import com.src.an.Constraint;
import com.src.an.Table;
import com.src.an.TableAnnotation;

public class Routes {
	@Constraint(constraint="primary key")
	private String routeId;
	private String routeSource;
	private String routeDestination;
	private String midStops;
	private String busNumber;
	
	public Routes(String routeId, String routeSource, String routeDestination, String midStops, String busNumber) {
		this.routeId = routeId;
		this.routeSource = routeSource;
		this.routeDestination = routeDestination;
		this.midStops = midStops;
		this.busNumber = busNumber;
	}
	
	public Routes() {
		if(this.getClass().isAnnotationPresent(TableAnnotation.class)) {
			Table.createTable(this.getClass().getCanonicalName());
		}
	}
	public Routes(String routeId) {
		this.routeId = routeId;
	}
	@Override
	public String toString() {
		return "Routes [routeId=" + routeId + ", routeSource=" + routeSource + ", routeDestination=" + routeDestination
				+ ", midStops=" + midStops + ", busNumber=" + busNumber + "]";
	}
	public String getRouteId() {
		return routeId;
	}
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}
	public String getRouteSource() {
		return routeSource;
	}
	public void setRouteSource(String routeSource) {
		this.routeSource = routeSource;
	}
	public String getRouteDestination() {
		return routeDestination;
	}
	public void setRouteDestination(String routeDestination) {
		this.routeDestination = routeDestination;
	}

	public String getMidStops() {
		return midStops;
	}
	public void setMidStops(String midStops) {
		this.midStops = midStops;
	}
	public String getBusNumber() {
		return busNumber;
	}
	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}
}
