package com.src.model;

import com.src.an.Constraint;
import com.src.an.Table;
import com.src.an.TableAnnotation;

public class Passenger {
	@Constraint(constraint="primary key")
	private String passengerId;
	private String passengerName;
	private int passengerAge;
	private String password;
	public Passenger(String passengerId, String passengerName, int passengerAge, String password,
			long passengerMobileNumber, String passengerEmailId) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.passengerAge = passengerAge;
		this.password = password;
		this.passengerMobileNumber = passengerMobileNumber;
		this.passengerEmailId = passengerEmailId;
	}
	public Passenger() {
		if(this.getClass().isAnnotationPresent(TableAnnotation.class)) {
			Table.createTable(this.getClass().getCanonicalName());
		}

	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getPassengerMobileNumber() {
		return passengerMobileNumber;
	}
	public void setPassengerMobileNumber(long passengerMobileNumber) {
		this.passengerMobileNumber = passengerMobileNumber;
	}
	private long passengerMobileNumber;
	private String passengerEmailId;

	public String getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public int getPassengerAge() {
		return passengerAge;
	}
	public void setPassengerAge(int passengerAge) {
		this.passengerAge = passengerAge;
	}
	
	public String getPassengerEmailId() {
		return passengerEmailId;
	}
	public void setPassengerEmailId(String passengerEmailId) {
		this.passengerEmailId = passengerEmailId;
	}
	public Passenger(String passengerId, String passengerName, int passengerAge, 
			String passengerEmailId) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.passengerAge = passengerAge;
		this.passengerEmailId = passengerEmailId;
	}
	public Passenger(String passengerId) {
		super();
		this.passengerId = passengerId;
	}
	
	
}
