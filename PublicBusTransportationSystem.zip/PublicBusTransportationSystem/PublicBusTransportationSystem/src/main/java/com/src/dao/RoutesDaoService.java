package com.src.dao;

import java.util.List;

import com.src.model.Routes;

public interface RoutesDaoService {
	
	public int addRoutes(Routes r);

	public int deleteRoutes(Routes r);

	public int updateRoutes(Routes r);

	public List<Routes> getRoutesBySrcDest(String source, String dest);

	public List<Routes> getAllRoutes();

	public double checkPrice(String routeId);
}
