package com.src.service;

import java.util.List;

import com.src.dao.PassengerDao;
import com.src.dao.PassengerDaoService;
import com.src.model.Passenger;

public class PassengerSevice implements PassengerServiceInterface {
	PassengerDaoService pds = new PassengerDao();
	@Override
	public int addPassenger(Passenger p) {
		// TODO Auto-generated method stub
		return pds.addPassenger(p);
	}

	@Override
	public int deletePassenger(Passenger p) {
		// TODO Auto-generated method stub
		return pds.deletePassenger(p);
	}

	@Override
	public int updatePassenger(Passenger p) {
		// TODO Auto-generated method stub
		return pds.updatePassenger(p);
	}

	@Override
	public Passenger getPassenger(String id) {
		// TODO Auto-generated method stub
		return pds.getPassenger(id);
	}

	@Override
	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		return pds.getAllPassengers();
	}

}
