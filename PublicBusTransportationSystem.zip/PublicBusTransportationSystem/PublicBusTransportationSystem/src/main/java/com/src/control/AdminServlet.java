package com.src.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.src.model.Passenger;
import com.src.model.Routes;
import com.src.service.PassengerServiceInterface;
import com.src.service.PassengerSevice;
import com.src.service.RoutesService;
import com.src.service.RoutesServiceInterface;

/**
 * Servlet implementation class AdminServlet
 */
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String mode = request.getParameter("mode");
		RoutesServiceInterface rdao = new RoutesService();
		PassengerServiceInterface psi = new PassengerSevice();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// request.getRequestDispatcher("adminPassengerDisplay.jsp");
		if (mode.equals("login")) {
			String username = request.getParameter("uname");
			String password = request.getParameter("pwd");
			if (username.equals("Your Usssername") && password.equals("Your Password")) {
				HttpSession id = request.getSession(true);
				id.setAttribute("username", username);
				 response.sendRedirect("adminHomePage.jsp");
			} else {
				out.print("<p><center>Invalid username or password, try Again.</center></p>");
				RequestDispatcher rd1 = request.getRequestDispatcher("adminLoginPage.jsp");
				rd1.include(request, response);
				// response.sendRedirect("adminLoginPage.jsp");

			}
		}
		else if (mode.equals("operations")) {
			RequestDispatcher adr = request.getRequestDispatcher("adminRoutesdisplay.jsp");
			
			String san = request.getParameter("san");
			if (san.equals("addRoutes")) {
				String routeId = request.getParameter("routeId");
				String source = request.getParameter("source");
				String midStops = request.getParameter("midStops");
				String destination = request.getParameter("destination");
				String busNumber = request.getParameter("busNumber");
				if(routeId.equals("") || source.equals("") || midStops.equals("")  || destination.equals("")  || busNumber.equals("") ) {
					
					out.print("<p><center><font color = 'red'>Insertion of null values is not allowed.</font></center></p>");
					adr.include(request, response);
				}
				else {
				Routes r = new Routes(routeId, source, destination, midStops, busNumber);
				int res = rdao.addRoutes(r);
				if (res > 0) {
					out.print("<p><center>New Routes Added Successfully.</center></p>");
					adr.include(request, response);
				} else {
					out.print("<p><center> Adding of New Routes Failed.</center></p>");
					adr.include(request, response);
				}
				}
			}
			if (san.equals("deleteRoutes")) {
				String routeId = request.getParameter("routeId");
				Routes r = new Routes(routeId);
				int res = rdao.deleteRoutes(r);
				if (res > 0) {
					
					out.write("<p><center>Deletion of Selected Route Succeded.</p></center>");
					adr.include(request, response);
				} else {
					
					out.write("<p><center>Deletion of Selected Route Failed,try Again Correctly.</p></center>");
					adr.include(request, response);
				}
			}
			if (san.equals("updateRoutes")) {
				String routeId = request.getParameter("routeId");
				String routeSource = request.getParameter("uSource");
				String routeStops = request.getParameter("uMidStops");
				String routeDestination = request.getParameter("uDestination");
				String busNumber = request.getParameter("uBusNumber");
				Routes r = new Routes(routeId, routeSource, routeDestination, routeStops, busNumber);
				int res = rdao.updateRoutes(r);
				if (res > 0) {
					out.print("<p><center>Updation of Selected Route Succeded.</p></center>");
					adr.include(request, response);
				} else {
					out.write("<p><center>Updation of Selected Route Failed, try Again Correctly.</p></center>");
					adr.include(request, response);
				}
			} 
		}
			else if (mode.equals("passengerreg")) {
				RequestDispatcher prd = request.getRequestDispatcher("passengerLogin.jsp");
				String userid = request.getParameter("userid");
				String username = request.getParameter("uname");
				String password = request.getParameter("upwd");
				int age = Integer.parseInt(request.getParameter("uage"));
				long mobile = Long.parseLong(request.getParameter("umobile"));
				String email = request.getParameter("uemail");
				Passenger p = new Passenger(userid, username, age, password, mobile, email);
				int res = psi.addPassenger(p);
				if (res > 0) {
					out.write("<p><center>Registration Success,You can now Login.</p></center>");
					prd.include(request, response);
				} else {
					out.write("<p><center>Unable to register.</p></center>");
					prd.include(request, response);
				}
			}
			else if (mode.equals("passengerLogin")) {
					String userid = request.getParameter("loginuserid");
					String password = request.getParameter("loginpassword");
					RequestDispatcher prd1 = request.getRequestDispatcher("passengerLogin.jsp");
					Passenger p = psi.getPassenger(userid);
					if(p==null) {
					prd1.include(request, response);
					out.write("<p><center>Credentials not found, kindly Register.</center></p>");
					}
					else if(p.getPassengerId().equals(userid) && p.getPassword().equals(password)) {
						HttpSession id = request.getSession(true);
						id.setAttribute("userid", userid);
						response.sendRedirect("passengerHomePage.jsp");
					}
					else  {
						
						out.write("<p><center>Invalid User Id or Password,Try Again.</center></p>");
						prd1.include(request, response);
					}
			}
			else if (mode.equals("checkprice")){
				String routeId = request.getParameter("routeId");
				double price = rdao.checkPrice(routeId);
				request.setAttribute("message","Price for your selected journey is :"+price+"/-");
				RequestDispatcher chk = request.getRequestDispatcher("searchRoutes.jsp");
				//out.print("<b><font color='green'><large>Price for your selected journey is :"+price+"/-</large></font><b>");
				chk.include(request, response);
			}
			else if(mode.equals("passengerlogout")) {
					HttpSession session = request.getSession();
					if (session != null) {
						session.invalidate();
						response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
						response.setHeader("Pragma", "no-cache");
						response.setDateHeader("Expires", 0);

					}
					response.sendRedirect("passengerLogin.jsp");
			}
			else if(mode.equals("adminlogout")) {
				HttpSession session1 = request.getSession();
				if (session1 != null) {
					session1.invalidate();
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
					response.setHeader("Pragma", "no-cache");
					response.setDateHeader("Expires", 0);

				}
				response.sendRedirect("adminLoginPage.jsp");
			}
			else if(mode.equals("deletePassenger")){
				String userId = request.getParameter("userid");
				Passenger p = psi.getPassenger(userId);
				int res = psi.deletePassenger(p);
				if(res>0) {
					out.write("Your account has been deleted");
					HttpSession session = request.getSession();
					if (session != null) {
						session.invalidate();
						response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
						response.setHeader("Pragma", "no-cache");
						response.setDateHeader("Expires", 0);

					}
					response.sendRedirect("passengerLogin.jsp");
				}
				else {
					out.write("unable to delete");
				}
			}
			else if(mode.equals("updatePassenger")) {
				String userid = request.getParameter("userid");
				String upname = request.getParameter("upname");
				String password = request.getParameter("uppwd");
				int age = Integer.parseInt(request.getParameter("upage"));
				long mobile = Long.parseLong(request.getParameter("upmobile"));
				String email = request.getParameter("upemail");
				Passenger p = new Passenger(userid, upname, age, password, mobile, email);
				int res = psi.updatePassenger(p);
				RequestDispatcher rd1 = request.getRequestDispatcher("passengerAccountDetails.jsp");
				if(res>0) {
					out.print("<p><center>Updation of Details in Profile succeeded.</center></p>");
					rd1.include(request, response);
				}
				else {
					out.print("Details cannot be updated");
					rd1.include(request, response);
				}
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
