package com.src.service;

import java.util.List;

import com.src.dao.RouteDao;
import com.src.dao.RoutesDaoService;
import com.src.model.Routes;

public class RoutesService implements RoutesServiceInterface{
	RoutesDaoService rds = new RouteDao();
	
	@Override
	public int addRoutes(Routes r) {
		// TODO Auto-generated method stub
		return rds.addRoutes(r);
	}

	@Override
	public int deleteRoutes(Routes r) {
		// TODO Auto-generated method stub
		return rds.deleteRoutes(r);
	}

	@Override
	public int updateRoutes(Routes r) {
		// TODO Auto-generated method stub
		return rds.updateRoutes(r);
	}

	@Override
	public List<Routes> getRoutesBySrcDest(String source, String dest) {
		// TODO Auto-generated method stub
		return rds.getRoutesBySrcDest(source, dest);
	}

	@Override
	public List<Routes> getAllRoutes() {
		// TODO Auto-generated method stub
		return rds.getAllRoutes();
	}

	@Override
	public double checkPrice(String routeId) {
		// TODO Auto-generated method stub
		return rds.checkPrice(routeId);
	}

}
